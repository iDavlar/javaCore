package module9Exam.exercise3;

public enum CarModel {
    CABRIOLET, PICKUP, SALOON
}
